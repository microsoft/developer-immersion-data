"use strict";
var OrderItem = (function () {
    function OrderItem() {
        this.Quantity = 1;
        this.Total = 0;
    }
    return OrderItem;
}());
exports.OrderItem = OrderItem;
//# sourceMappingURL=order-item.entity.js.map