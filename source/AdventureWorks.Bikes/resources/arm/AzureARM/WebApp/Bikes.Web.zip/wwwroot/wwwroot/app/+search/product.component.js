"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var card_component_1 = require('../+product/card.component');
var router_1 = require('@angular/router');
var product_service_1 = require('../shared/product/product.service');
var message_service_1 = require('../shared/message/message.service');
var SearchProductComponent = (function () {
    function SearchProductComponent(routeParams, productService, globalMessages) {
        this.routeParams = routeParams;
        this.productService = productService;
        this.globalMessages = globalMessages;
        this.Items = [];
        this.IsRefreshing = false;
        this.Term = routeParams.getParam('term');
    }
    SearchProductComponent.prototype.ngOnInit = function () {
        this.globalMessages.removeMessages();
        this.LoadMore();
    };
    SearchProductComponent.prototype.LoadMore = function () {
        var _this = this;
        this.IsRefreshing = true;
        this.productService
            .search(this.Term)
            .subscribe(function (products) {
            _this.Items = products;
            _this.TotalResults = _this.Items.length;
            _this.IsRefreshing = false;
        }, function (err) {
            if (err === 500) {
                _this.globalMessages.addError('Server connection error');
            }
            _this.TotalResults = 0;
            _this.IsRefreshing = false;
        });
        this.IsRefreshing = false;
    };
    SearchProductComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'aw-search-product',
            templateUrl: 'product.component.html',
            providers: [product_service_1.ProductService],
            directives: [card_component_1.ProductCardComponent, router_1.ROUTER_DIRECTIVES]
        }), 
        __metadata('design:paramtypes', [router_1.RouteSegment, product_service_1.ProductService, message_service_1.MessageService])
    ], SearchProductComponent);
    return SearchProductComponent;
}());
exports.SearchProductComponent = SearchProductComponent;
//# sourceMappingURL=product.component.js.map