"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var order_service_1 = require('../shared/order/order.service');
var security_service_1 = require('../shared/security/security.service');
var store_service_1 = require('../shared/store/store.service');
var message_service_1 = require('../shared/message/message.service');
var header_component_1 = require('../+store/header.component');
var BackofficeStoreComponent = (function () {
    function BackofficeStoreComponent(orderService, security, router, storeService, globalMessages) {
        this.orderService = orderService;
        this.security = security;
        this.router = router;
        this.storeService = storeService;
        this.globalMessages = globalMessages;
        this.Orders = [];
        this.Customers = [];
        this.Store = null;
        this.Section = '';
        this.LoadingOrders = false;
        this.LoadingCustomers = false;
        this.Section = 'orders';
    }
    BackofficeStoreComponent.prototype.ngOnInit = function () {
        if (!this.security.User) {
            this.router.navigate(['/']);
        }
        else {
            this.LoadStore();
            this.LoadOrders();
        }
    };
    BackofficeStoreComponent.prototype.LoadStore = function () {
        var _this = this;
        if (this.security.User.store) {
            this.Store = this.security.User.store;
        }
        else {
            this.storeService.getUserStore(this.security)
                .subscribe(function (store) {
                _this.security.User.store = store;
                _this.Store = store;
            });
        }
    };
    BackofficeStoreComponent.prototype.LoadOrders = function () {
        var _this = this;
        this.LoadingOrders = true;
        this.Orders = [];
        this.orderService.getAll().subscribe(function (list) {
            _this.Orders = list;
            _this.LoadingOrders = false;
        }, function (error) {
            if (error === 500) {
                _this.globalMessages.ErrorMessages.push('Server connection error');
            }
            _this.LoadingOrders = false;
        });
    };
    BackofficeStoreComponent.prototype.LoadCustomers = function () {
        var _this = this;
        this.LoadingCustomers = true;
        this.Customers = [];
        this.orderService.getAllCustomers().subscribe(function (list) {
            _this.Customers = list;
            _this.LoadingCustomers = false;
        }, function (error) {
            if (error === 500) {
                _this.globalMessages.ErrorMessages.push('Server connection error');
            }
            _this.LoadingCustomers = false;
        });
    };
    BackofficeStoreComponent.prototype.getStatusName = function (status) {
        switch (status) {
            case 1:
                return 'Pending';
            case 2:
                return 'Payment Accepted';
            case 3:
                return 'Shipped';
            default:
                return 'Unknown';
        }
    };
    BackofficeStoreComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'aw-backoffice',
            templateUrl: 'store.component.html',
            providers: [order_service_1.OrderService, store_service_1.StoreService],
            directives: [router_1.ROUTER_DIRECTIVES, header_component_1.StoreHeaderComponent]
        }), 
        __metadata('design:paramtypes', [order_service_1.OrderService, security_service_1.SecurityService, router_1.Router, store_service_1.StoreService, message_service_1.MessageService])
    ], BackofficeStoreComponent);
    return BackofficeStoreComponent;
}());
exports.BackofficeStoreComponent = BackofficeStoreComponent;
//# sourceMappingURL=store.component.js.map