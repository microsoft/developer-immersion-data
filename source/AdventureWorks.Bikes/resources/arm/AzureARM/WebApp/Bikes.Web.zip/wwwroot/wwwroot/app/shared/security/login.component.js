"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var modal_config_1 = require('../modal.config');
var security_service_1 = require('./security.service');
var store_service_1 = require('../store/store.service');
var router_1 = require('@angular/router');
var LoginComponent = (function () {
    function LoginComponent(ModalConfig, securityService, router, storeService) {
        this.ModalConfig = ModalConfig;
        this.securityService = securityService;
        this.router = router;
        this.storeService = storeService;
        this.Checking = false;
        this.Error = false;
    }
    LoginComponent.prototype.remainOpen = function (event) {
        event.stopPropagation();
    };
    LoginComponent.prototype.doLogin = function () {
        var _this = this;
        this.Checking = true;
        this.Error = false;
        this.securityService.getTokenRequest(this.Username, this.Password)
            .subscribe(function (json) {
            _this.securityService.Token = json.access_token;
            _this.securityService.getUser().subscribe(function (user) {
                _this.securityService.User = user;
                _this.Checking = false;
                _this.router.navigate(['/backoffice']);
                _this.ModalConfig.closeLogin();
            });
        }, function (err) {
            _this.Checking = false;
            if (err.status === 500) {
                _this.ModalConfig.closeLogin();
            }
            else {
                _this.Error = true;
            }
        });
    };
    LoginComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'aw-login-modal',
            templateUrl: 'login.component.html',
            providers: [store_service_1.StoreService]
        }), 
        __metadata('design:paramtypes', [modal_config_1.ModalConfig, security_service_1.SecurityService, router_1.Router, store_service_1.StoreService])
    ], LoginComponent);
    return LoginComponent;
}());
exports.LoginComponent = LoginComponent;
//# sourceMappingURL=login.component.js.map