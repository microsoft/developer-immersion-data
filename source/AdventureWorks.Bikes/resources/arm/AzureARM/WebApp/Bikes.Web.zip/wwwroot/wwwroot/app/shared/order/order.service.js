"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
var security_service_1 = require('../security/security.service');
var order_list_entity_1 = require('./order-list.entity');
var customer_list_entity_1 = require('./customer-list.entity');
var api_config_1 = require('../api.config');
require('rxjs/add/observable/from');
require('rxjs/add/operator/map');
var OrderService = (function () {
    function OrderService(http, config, security) {
        this.http = http;
        this.config = config;
        this.security = security;
    }
    OrderService.prototype.getAll = function (limit) {
        if (limit === void 0) { limit = 12; }
        return this.http.get(this.config.ROOT_URL + 'orders/all?count=' + limit, new http_1.RequestOptions({
            headers: this.security.getRequestHeaders()
        }))
            .map(function (response) {
            var list = new Array();
            response.json().forEach(function (item) {
                var orderItem = new order_list_entity_1.OrderList();
                orderItem.hidrate(item);
                list.push(orderItem);
            });
            return list;
        });
    };
    OrderService.prototype.getAllCustomers = function (limit) {
        if (limit === void 0) { limit = 12; }
        return this.http.get(this.config.ROOT_URL + 'customers/all?count=' + limit, new http_1.RequestOptions({
            headers: this.security.getRequestHeaders()
        }))
            .map(function (response) {
            var list = new Array();
            response.json().forEach(function (item) {
                var customerItem = new customer_list_entity_1.CustomerList();
                customerItem.hidrate(item);
                list.push(customerItem);
            });
            return list;
        });
    };
    OrderService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http, api_config_1.APIConfig, security_service_1.SecurityService])
    ], OrderService);
    return OrderService;
}());
exports.OrderService = OrderService;
//# sourceMappingURL=order.service.js.map