"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var product_service_1 = require('../shared/product/product.service');
var store_service_1 = require('../shared/store/store.service');
var cart_service_1 = require('../shared/order/cart.service');
var cart_modal_component_1 = require('../shared/order/cart-modal.component');
var message_service_1 = require('../shared/message/message.service');
var card_component_1 = require('./card.component');
var header_component_1 = require('../+store/header.component');
var router_1 = require('@angular/router');
var truncate_1 = require('../shared/pipes/truncate');
var modal_config_1 = require('../shared/modal.config');
var ProductDetailComponent = (function () {
    function ProductDetailComponent(ModalConfig, productService, storeService, cartService, routeParams, globalMessages) {
        this.ModalConfig = ModalConfig;
        this.productService = productService;
        this.storeService = storeService;
        this.cartService = cartService;
        this.routeParams = routeParams;
        this.globalMessages = globalMessages;
        this.Product = null;
        this.Store = null;
        this.Related = [];
        this.IsRefreshing = false;
        this.Section = 'details';
    }
    ProductDetailComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.globalMessages.removeMessages();
        var id = parseInt(this.routeParams.getParam('id'));
        this.ImageUrl = this.productService.getImageUrl(id);
        this.productService.get(id)
            .subscribe(function (product) {
            _this.Product = product;
            _this.storeService.get(_this.Product.storeId).subscribe(function (store) { return _this.Store = store; });
            _this.LoadRelated();
        }, function () {
            _this.globalMessages.ErrorMessages.push('Server connection error');
        });
    };
    ProductDetailComponent.prototype.LoadRelated = function () {
        var _this = this;
        this.IsRefreshing = false;
        this.productService
            .getRelated(this.Product.name)
            .subscribe(function (ids) {
            ids.forEach(function (id) {
                _this.productService.get(id).subscribe(function (product) {
                    _this.Related.push(product);
                    _this.IsRefreshing = false;
                }, function () {
                    _this.globalMessages.addError('Server connection error');
                    _this.IsRefreshing = false;
                });
            });
        }, function () {
            _this.globalMessages.addError('Server connection error');
            _this.IsRefreshing = false;
        });
    };
    ProductDetailComponent.prototype.AddToCart = function () {
        this.cartService.add(this.Product);
        this.ModalConfig.openCartNotice();
    };
    ProductDetailComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'aw-product-detail',
            templateUrl: 'detail.component.html',
            pipes: [truncate_1.TruncatePipe],
            providers: [product_service_1.ProductService],
            directives: [card_component_1.ProductCardComponent, header_component_1.StoreHeaderComponent, cart_modal_component_1.CartModalComponent, router_1.ROUTER_DIRECTIVES]
        }), 
        __metadata('design:paramtypes', [modal_config_1.ModalConfig, product_service_1.ProductService, store_service_1.StoreService, cart_service_1.CartService, router_1.RouteSegment, message_service_1.MessageService])
    ], ProductDetailComponent);
    return ProductDetailComponent;
}());
exports.ProductDetailComponent = ProductDetailComponent;
//# sourceMappingURL=detail.component.js.map