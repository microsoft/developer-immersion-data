"use strict";
var ModalConfig = (function () {
    function ModalConfig() {
        this.CartNoticeModal = false;
        this.LoginModal = false;
    }
    ModalConfig.prototype.openLogin = function () {
        this.LoginModal = true;
    };
    ModalConfig.prototype.closeLogin = function () {
        this.LoginModal = false;
    };
    ModalConfig.prototype.openCartNotice = function () {
        this.CartNoticeModal = true;
    };
    ModalConfig.prototype.closeCartNotice = function () {
        this.CartNoticeModal = false;
    };
    return ModalConfig;
}());
exports.ModalConfig = ModalConfig;
//# sourceMappingURL=modal.config.js.map