"use strict";
var Product = (function () {
    function Product(productId, name, originalPrice, finalPrice, discount, storeId, storeName, store, description, remainingUnits, specs) {
        if (productId === void 0) { productId = null; }
        if (name === void 0) { name = ''; }
        if (originalPrice === void 0) { originalPrice = 0; }
        if (finalPrice === void 0) { finalPrice = 0; }
        if (discount === void 0) { discount = 0; }
        if (storeId === void 0) { storeId = null; }
        if (storeName === void 0) { storeName = ''; }
        if (store === void 0) { store = null; }
        if (description === void 0) { description = ''; }
        if (remainingUnits === void 0) { remainingUnits = 0; }
        if (specs === void 0) { specs = []; }
        this.productId = productId;
        this.name = name;
        this.originalPrice = originalPrice;
        this.finalPrice = finalPrice;
        this.discount = discount;
        this.storeId = storeId;
        this.storeName = storeName;
        this.store = store;
        this.description = description;
        this.remainingUnits = remainingUnits;
        this.specs = specs;
    }
    ;
    return Product;
}());
exports.Product = Product;
//# sourceMappingURL=product.entity.js.map