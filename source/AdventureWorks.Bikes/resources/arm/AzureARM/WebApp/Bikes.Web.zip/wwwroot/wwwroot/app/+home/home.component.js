"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var home_offer_component_1 = require('./home-offer.component');
var product_service_1 = require('../shared/product/product.service');
var store_service_1 = require('../shared/store/store.service');
var message_service_1 = require('../shared/message/message.service');
var card_component_1 = require('../+product/card.component');
var router_1 = require('@angular/router');
var HomeComponent = (function () {
    function HomeComponent(router, productService, storeService, globalMessages) {
        this.router = router;
        this.productService = productService;
        this.storeService = storeService;
        this.globalMessages = globalMessages;
        this.Stores = [];
        this.Offers = [];
        this.Bikes = [];
        this.LoadingStores = false;
        this.LoadingOffers = false;
        this.LoadingBikes = false;
        this.SearchTerm = '';
    }
    HomeComponent.prototype.ngOnInit = function () {
        this.globalMessages.removeMessages();
        this.LoadStores();
        this.LoadOffers();
        this.LoadBikes();
    };
    HomeComponent.prototype.LoadBikes = function () {
        var _this = this;
        this.LoadingBikes = true;
        this.productService
            .getAll(9)
            .subscribe(function (products) { return _this.Bikes = products; }, function () {
            _this.globalMessages.addError('Server connection error');
            _this.LoadingBikes = false;
        }, function () { return _this.LoadingBikes = false; });
    };
    HomeComponent.prototype.LoadOffers = function () {
        var _this = this;
        this.LoadingOffers = true;
        this.productService
            .getHighlighted()
            .subscribe(function (products) { return _this.Offers = products; }, function () {
            _this.globalMessages.addError('Server connection error');
            _this.LoadingOffers = false;
        }, function () { return _this.LoadingOffers = false; });
    };
    HomeComponent.prototype.LoadStores = function () {
        var _this = this;
        this.LoadingStores = true;
        this.storeService
            .getAll()
            .subscribe(function (stores) { return _this.Stores = stores; }, function () {
            _this.globalMessages.addError('Server connection error');
            _this.LoadingStores = false;
        }, function () { return _this.LoadingStores = false; });
    };
    HomeComponent.prototype.SearchKeyPress = function (key) {
        if (key === 13 && this.SearchTerm.length > 0) {
            this.router.navigate(['/search', this.SearchTerm]);
        }
    };
    HomeComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'aw-home',
            templateUrl: 'home.component.html',
            providers: [product_service_1.ProductService, store_service_1.StoreService],
            directives: [home_offer_component_1.HomeOfferComponent, card_component_1.ProductCardComponent, router_1.ROUTER_DIRECTIVES]
        }), 
        __metadata('design:paramtypes', [router_1.Router, product_service_1.ProductService, store_service_1.StoreService, message_service_1.MessageService])
    ], HomeComponent);
    return HomeComponent;
}());
exports.HomeComponent = HomeComponent;
//# sourceMappingURL=home.component.js.map