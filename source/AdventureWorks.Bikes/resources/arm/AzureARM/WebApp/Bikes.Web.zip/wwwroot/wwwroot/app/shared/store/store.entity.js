"use strict";
var Store = (function () {
    function Store(storeId, name, description, products, address, distance, city, state, country) {
        if (storeId === void 0) { storeId = null; }
        if (name === void 0) { name = ''; }
        if (description === void 0) { description = ''; }
        if (products === void 0) { products = []; }
        if (address === void 0) { address = ''; }
        if (distance === void 0) { distance = 0; }
        if (city === void 0) { city = ''; }
        if (state === void 0) { state = ''; }
        if (country === void 0) { country = ''; }
        this.storeId = storeId;
        this.name = name;
        this.description = description;
        this.products = products;
        this.address = address;
        this.distance = distance;
        this.city = city;
        this.state = state;
        this.country = country;
    }
    ;
    return Store;
}());
exports.Store = Store;
//# sourceMappingURL=store.entity.js.map