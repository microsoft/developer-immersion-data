"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var order_entity_1 = require('./order.entity');
var order_item_entity_1 = require('./order-item.entity');
var core_1 = require('@angular/core');
var CartService = (function () {
    function CartService() {
        this.Count = 0;
        this.Total = 0;
        this.Order = new order_entity_1.Order();
    }
    CartService.prototype.total = function () {
        return this.Order.Total;
    };
    CartService.prototype.getItems = function () {
        return this.Order.Items;
    };
    CartService.prototype.add = function (Item) {
        var inCart = false;
        this.Order.Items.forEach(function (orderItem) {
            if (orderItem.Product.productId === Item.productId) {
                inCart = true;
                orderItem.Quantity++;
                orderItem.Total = orderItem.Product.finalPrice * orderItem.Quantity;
            }
        });
        if (!inCart) {
            var orderItem = new order_item_entity_1.OrderItem();
            orderItem.Product = Item;
            orderItem.Quantity = 1;
            orderItem.Total = Item.finalPrice;
            this.Order.Items.push(orderItem);
        }
        this.recalculate();
    };
    CartService.prototype.remove = function (Item) {
        var orderItemSelected = null;
        this.Order.Items.forEach(function (orderItem) {
            if (orderItem.Product.productId === Item.productId) {
                orderItemSelected = orderItem;
            }
        });
        if (orderItemSelected) {
            if (orderItemSelected.Quantity > 1) {
                orderItemSelected.Quantity--;
                orderItemSelected.Total = orderItemSelected.Product.finalPrice * orderItemSelected.Quantity;
            }
            else {
                var index = this.Order.Items.indexOf(orderItemSelected, 0);
                if (index > -1) {
                    this.Order.Items.splice(index, 1);
                }
            }
        }
        this.recalculate();
    };
    CartService.prototype.recalculate = function () {
        var _this = this;
        this.Order.Total = 0;
        this.Count = 0;
        this.Order.Items.forEach(function (orderItem) {
            _this.Order.Total += orderItem.Total;
            _this.Count += orderItem.Quantity;
        });
        this.Total = this.Order.Total;
    };
    CartService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], CartService);
    return CartService;
}());
exports.CartService = CartService;
//# sourceMappingURL=cart.service.js.map