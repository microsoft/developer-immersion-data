"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var card_component_1 = require('../+product/card.component');
var header_component_1 = require('./header.component');
var router_1 = require('@angular/router');
var product_service_1 = require('../shared/product/product.service');
var store_service_1 = require('../shared/store/store.service');
var message_service_1 = require('../shared/message/message.service');
var StoreDetailComponent = (function () {
    function StoreDetailComponent(productService, storeService, routeParams, globalMessages) {
        this.productService = productService;
        this.storeService = storeService;
        this.routeParams = routeParams;
        this.globalMessages = globalMessages;
        this.Featured = [];
        this.Trending = [];
        this.Arrivals = [];
        this.IsRefreshing = false;
    }
    StoreDetailComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.globalMessages.removeMessages();
        var id = parseInt(this.routeParams.getParam('id'));
        this.BackgroundImageUrl = this.storeService.getImageUrl(id);
        this.storeService.get(id)
            .subscribe(function (store) {
            _this.Store = store;
            _this.Load('featured');
        }, function () {
            _this.globalMessages.ErrorMessages.push('Server connection error');
        });
    };
    StoreDetailComponent.prototype.Load = function (section, page) {
        var _this = this;
        if (page === void 0) { page = 1; }
        this.IsRefreshing = true;
        this.Section = section;
        switch (this.Section) {
            case 'featured':
                if (page === 1)
                    this.Featured = [];
                this.productService
                    .getFromStore(this.Store.storeId, 12)
                    .subscribe(function (products) {
                    _this.Featured = products;
                    _this.IsRefreshing = false;
                }, function () {
                    _this.globalMessages.addError('Server connection error');
                    _this.IsRefreshing = false;
                });
                break;
            case 'arrivals':
                if (page === 1)
                    this.Arrivals = [];
                this.productService
                    .getFromStore(this.Store.storeId, 12)
                    .subscribe(function (products) {
                    _this.Arrivals = products;
                    _this.IsRefreshing = false;
                }, function () {
                    _this.globalMessages.addError('Server connection error');
                    _this.IsRefreshing = false;
                });
                break;
            case 'trends':
                if (page === 1)
                    this.Trending = [];
                this.productService
                    .getFromStore(this.Store.storeId, 12)
                    .subscribe(function (products) {
                    _this.Trending = products;
                    _this.IsRefreshing = false;
                }, function () {
                    _this.globalMessages.addError('Server connection error');
                    _this.IsRefreshing = false;
                });
                break;
        }
    };
    StoreDetailComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'aw-store-detail',
            templateUrl: 'detail.component.html',
            providers: [product_service_1.ProductService, store_service_1.StoreService],
            directives: [card_component_1.ProductCardComponent, header_component_1.StoreHeaderComponent, router_1.ROUTER_DIRECTIVES]
        }), 
        __metadata('design:paramtypes', [product_service_1.ProductService, store_service_1.StoreService, router_1.RouteSegment, message_service_1.MessageService])
    ], StoreDetailComponent);
    return StoreDetailComponent;
}());
exports.StoreDetailComponent = StoreDetailComponent;
//# sourceMappingURL=detail.component.js.map