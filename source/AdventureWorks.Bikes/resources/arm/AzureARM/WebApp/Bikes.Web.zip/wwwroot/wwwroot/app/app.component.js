"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var http_1 = require('@angular/http');
var home_component_1 = require('./+home/home.component');
var stores_component_1 = require('./+store/stores.component');
var detail_component_1 = require('./+store/detail.component');
var product_component_1 = require('./+search/product.component');
var detail_component_2 = require('./+product/detail.component');
var store_component_1 = require('./+backoffice/store.component');
var cart_component_1 = require('./+order/cart.component');
var index_1 = require('./shared/index');
var AppComponent = (function () {
    function AppComponent(ModalConfig, Security, router) {
        this.ModalConfig = ModalConfig;
        this.Security = Security;
        this.router = router;
    }
    AppComponent.prototype.isActiveRoute = function (route) {
        return this.router.serializeUrl(this.router.urlTree) === this.router.serializeUrl((this.router.createUrlTree([route])));
    };
    AppComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'sd-app',
            viewProviders: [http_1.HTTP_PROVIDERS],
            templateUrl: 'app.component.html',
            directives: [router_1.ROUTER_DIRECTIVES, index_1.NavbarComponent, index_1.MessageComponent, index_1.LoginComponent, index_1.CartModalComponent]
        }),
        router_1.Routes([
            {
                path: '/',
                component: home_component_1.HomeComponent
            },
            {
                path: '/cart',
                component: cart_component_1.CartComponent
            },
            {
                path: '/stores/:id',
                component: detail_component_1.StoreDetailComponent
            },
            {
                path: '/stores',
                component: stores_component_1.StoresComponent
            },
            {
                path: '/search/:term',
                component: product_component_1.SearchProductComponent
            },
            {
                path: '/products/:id',
                component: detail_component_2.ProductDetailComponent
            },
            {
                path: '/backoffice',
                component: store_component_1.BackofficeStoreComponent
            }
        ]), 
        __metadata('design:paramtypes', [index_1.ModalConfig, index_1.SecurityService, router_1.Router])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map