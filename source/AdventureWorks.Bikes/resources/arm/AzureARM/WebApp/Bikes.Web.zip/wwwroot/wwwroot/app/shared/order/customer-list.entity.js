"use strict";
var CustomerList = (function () {
    function CustomerList() {
        this.customerId = 0;
        this.firstName = 'string';
        this.lastName = 'string';
        this.address = 'string';
        this.zipCode = 'string';
        this.city = 'string';
        this.state = 'string';
        this.country = 'string';
        this.phone = 'string';
        this.email = 'string';
        this.creditCardNumber = 'string';
        this.sales = 0;
        this.registrationDate = '';
        this.registrationDateHidrated = null;
        this.lastOrder = '';
        this.lastOrderHidrated = null;
    }
    CustomerList.prototype.hidrateDates = function () {
        this.lastOrderHidrated = new Date(this.lastOrder);
        this.registrationDateHidrated = new Date(this.registrationDate);
    };
    CustomerList.prototype.hidrate = function (json) {
        this.customerId = json.customerId;
        this.firstName = json.firstName;
        this.lastName = json.lastName;
        this.email = json.email;
        this.registrationDate = json.registrationDate;
        this.lastOrder = json.lastOrder;
        this.sales = json.sales;
        this.creditCardNumber = json.creditCardNumber;
        this.hidrateDates();
    };
    return CustomerList;
}());
exports.CustomerList = CustomerList;
//# sourceMappingURL=customer-list.entity.js.map