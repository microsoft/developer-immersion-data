"use strict";
var common_1 = require('@angular/common');
var core_1 = require('@angular/core');
var platform_browser_dynamic_1 = require('@angular/platform-browser-dynamic');
var router_1 = require('@angular/router');
var http_1 = require('@angular/http');
var cart_service_1 = require('./shared/order/cart.service');
var store_service_1 = require('./shared/store/store.service');
var api_config_1 = require('./shared/api.config');
var message_service_1 = require('./shared/message/message.service');
var app_component_1 = require('./app.component');
var modal_config_1 = require('./shared/modal.config');
var security_service_1 = require('./shared/security/security.service');
if ('<%= ENV %>' === 'prod') {
    core_1.enableProdMode();
}
platform_browser_dynamic_1.bootstrap(app_component_1.AppComponent, [
    router_1.ROUTER_PROVIDERS,
    http_1.HTTP_PROVIDERS,
    cart_service_1.CartService,
    api_config_1.APIConfig,
    store_service_1.StoreService,
    message_service_1.MessageService,
    modal_config_1.ModalConfig,
    security_service_1.SecurityService,
    core_1.provide(common_1.LocationStrategy, { useClass: common_1.HashLocationStrategy }),
    core_1.provide(common_1.APP_BASE_HREF, { useValue: '<%= APP_BASE %>' })
]);
//# sourceMappingURL=main.js.map