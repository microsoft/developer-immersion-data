"use strict";
var Order = (function () {
    function Order() {
        this.Total = 0;
        this.Items = [];
    }
    return Order;
}());
exports.Order = Order;
//# sourceMappingURL=order.entity.js.map