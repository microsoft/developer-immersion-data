"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var card_component_1 = require('../+product/card.component');
var router_1 = require('@angular/router');
var product_service_1 = require('../shared/product/product.service');
var store_service_1 = require('../shared/store/store.service');
var message_service_1 = require('../shared/message/message.service');
var StoresComponent = (function () {
    function StoresComponent(productService, storeService, globalMessages) {
        this.productService = productService;
        this.storeService = storeService;
        this.globalMessages = globalMessages;
        this.LocationAvailable = true;
        this.LoadingLatests = false;
        this.LoadingNearest = false;
        this.Latests = [];
        this.Nearest = [];
        this.PlaceName = '';
    }
    StoresComponent.prototype.ngOnInit = function () {
        this.globalMessages.removeMessages();
        this.LoadNearStores();
        this.LoadLatests();
    };
    StoresComponent.prototype.LoadNearStores = function () {
        var _this = this;
        this.PlaceName = this.storeService.CityName;
        this.storeService
            .getNearBy(3)
            .subscribe(function (stores) {
            _this.Nearest = stores;
            _this.Nearest.forEach(function (store) { return _this.LoadProductsFromStore(store); });
            _this.LoadingNearest = false;
        }, function () {
            _this.globalMessages.addError('Server connection error');
            _this.LoadingNearest = false;
        }, function () { return _this.LoadingNearest = false; });
    };
    StoresComponent.prototype.LoadLatests = function () {
        var _this = this;
        this.LoadingLatests = true;
        this.storeService
            .getAll(6)
            .subscribe(function (stores) { return _this.Latests = stores; }, function () {
            _this.globalMessages.addError('Server connection error');
            _this.LoadingLatests = false;
        }, function () { return _this.LoadingLatests = false; });
    };
    StoresComponent.prototype.Meters2Miles = function (meters) {
        return meters * 0.000621371192;
    };
    StoresComponent.prototype.LoadProductsFromStore = function (store) {
        var _this = this;
        this.productService
            .getFromStore(store.storeId, 3)
            .subscribe(function (products) { return store.products = products; }, function () { return _this.globalMessages.addError('Server connection error'); });
    };
    StoresComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'aw-stores',
            templateUrl: 'stores.component.html',
            providers: [product_service_1.ProductService, store_service_1.StoreService],
            directives: [card_component_1.ProductCardComponent, router_1.ROUTER_DIRECTIVES]
        }), 
        __metadata('design:paramtypes', [product_service_1.ProductService, store_service_1.StoreService, message_service_1.MessageService])
    ], StoresComponent);
    return StoresComponent;
}());
exports.StoresComponent = StoresComponent;
//# sourceMappingURL=stores.component.js.map