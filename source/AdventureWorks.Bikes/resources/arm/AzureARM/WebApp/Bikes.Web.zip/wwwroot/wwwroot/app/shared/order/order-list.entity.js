"use strict";
var OrderList = (function () {
    function OrderList() {
        this.orderId = 0;
        this.totalPrice = 0;
        this.date = '';
        this.dateHidrated = null;
        this.status = 'Unknown';
        this.customer = 'Unknown';
        this.delivery = 'Unknown';
        this.payment = 'Unknown';
    }
    OrderList.prototype.hidrateDates = function () {
        this.dateHidrated = new Date(this.date);
    };
    OrderList.prototype.hidrate = function (json) {
        this.orderId = json.orderId;
        this.customer = json.customer;
        this.date = json.date;
        this.payment = json.payment;
        this.delivery = json.delivery;
        this.status = json.status;
        this.totalPrice = json.totalPrice;
        this.hidrateDates();
    };
    return OrderList;
}());
exports.OrderList = OrderList;
//# sourceMappingURL=order-list.entity.js.map